--COMP 421
--Group 11
--Project Part 2
--Inserts into one relation

INSERT INTO users VALUES (
	1,
	'furrymachine@gmail.com',
	'woofwoof123'
);

INSERT INTO users VALUES (
	2,
	'phil@yahoo.com',
	'password'
);

INSERT INTO users VALUES (
	3,
	'australia@outbackgrill.com',
	'icantrememberthis321'
);

INSERT INTO users VALUES (
	4,
	'ihateinsertstatements@everyone.com',
	'whyyyyyyY'
);

INSERT INTO users VALUES (
	5,
	'cat@daddy.com',
	'purrrfect'
);

SELECT * FROM users;
