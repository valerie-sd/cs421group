COMP 421
GROUP 11
Project PART 2

David Blader 
Valerie Saunders Duncan 
Yang David Zhou 
Gurshane Sidhu

docs -- contains updated verion of part one and the required output/info for part 2
src  -- contains the sql files required for this portion